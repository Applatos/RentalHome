﻿namespace Sommerhus.Contracts.Dtos.Admin.Houses;
// ---------- Houses (paged master) ----------
public sealed class HousePageDto
{
    public string? Query { get; set; }
    public int Page { get; set; }
    public int PageSize { get; set; }
    public int Total { get; set; }
    public List<HouseListItemDto> Items { get; set; } = new();
}
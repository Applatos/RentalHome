using System.Collections.Generic;

namespace Sommerhus.Contracts.Dtos.Admin.Areas;

public record AreaDetailsDto(Guid Id, string Slug, string Name, string? Description, List<AreaImageDto> Images);
public record AreaImageDto(Guid Id, string Url);
public record AreaListItemDto(Guid Id, string Slug, string Name, int HouseCount, int ImageCount);

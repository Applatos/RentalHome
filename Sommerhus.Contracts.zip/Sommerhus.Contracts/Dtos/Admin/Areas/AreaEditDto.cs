﻿using Sommerhus.Contracts.Dtos.Shared;

namespace Sommerhus.Contracts.Dtos.Admin.Areas;

public record AreaEditDto(
    Guid? Id,                 // null ved "opret", udfyldt ved "rediger"
    string Slug,              // tom ved "opret"
    string Name,              // udfyldes af bruger
    Guid? CityId,             // valgt city (optional)
    string? Description,      // HTML/tekst
    IReadOnlyList<ImageDto> Images,           // eksisterende billeder (kan vises read-only)
    IReadOnlyList<LookupItem> Cities          // dropdown-kilder
);

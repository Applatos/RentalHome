﻿using System.ComponentModel.DataAnnotations;

namespace Sommerhus.Contracts.Dtos.Admin.Areas;

public record CreateAreaDto(
    [Required] string Name,
    string? Description,
    Guid? CityId,
    List<string>? Images
);
